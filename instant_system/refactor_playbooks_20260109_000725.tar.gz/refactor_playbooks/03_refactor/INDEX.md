# 03_refactor 重構劇本索引

> 本索引列出所有重構劇本檔案、對應的 cluster、狀態與最後更新時間。

---

## 🎯 當前執行狀態

**三階段重構計劃執行中** (2026-01-05)

```
Phase 1 (Core Cluster)    → 🟢 文檔完成，準備執行
Phase 2 (Scale)           → ⚪ 待 Phase 1 完成後啟動
Phase 3 (Infrastructure)  → ⚪ 待 Phase 2 完成後啟動
```

---

## 📊 統計摘要

- **總劇本數**：4
- **完成**：0
- **進行中**：1 (core/architecture-stability)
- **草稿**：3
- **覆蓋率**：已覆蓋 4/8 個主要 clusters

---

## 📁 劇本清單

### Core Domain

| 檔案 | Cluster ID | 狀態 | 最後更新 | 說明 |
|------|------------|------|----------|------|
| [core__architecture_refactor.md](core/core__architecture_refactor.md) | `core/architecture-stability` | 🟢 進行中 | 2026-01-05 | 核心架構穩定性重構 (Phase 1) |

### Services Domain

| 檔案 | Cluster ID | 狀態 | 最後更新 | 說明 |
|------|------------|------|----------|------|
| [services__gateway_refactor.md](services/services__gateway_refactor.md) | `services/gateway` | 🟡 草稿 | 2025-12-06 | Gateway 服務重構 |
| _待補充_ | `services/agents` | ⚪ 待建立 | - | Agents 服務重構 |

### Automation Domain

| 檔案 | Cluster ID | 狀態 | 最後更新 | 說明 |
|------|------------|------|----------|------|
| [automation__autonomous_refactor.md](automation/automation__autonomous_refactor.md) | `automation/autonomous` | 🟡 草稿 | 2025-12-06 | 五骨架自主系統重構 (Phase 2) |
| _待補充_ | `automation/architect` | ⚪ 待建立 | - | 架構分析模組重構 |
| _待補充_ | `automation/hyperautomation` | ⚪ 待建立 | - | 超自動化策略重構 |

### Apps Domain

| 檔案 | Cluster ID | 狀態 | 最後更新 | 說明 |
|------|------------|------|----------|------|
| [apps__web_refactor.md](apps/apps__web_refactor.md) | `apps/web` | 🟡 草稿 | 2025-12-06 | Web 應用重構 |

### Governance Domain

| 檔案 | Cluster ID | 狀態 | 最後更新 | 說明 |
|------|------------|------|----------|------|
| _待補充_ | `governance/schemas` | ⚪ 待建立 | - | Schema 治理重構 |
| _待補充_ | `governance/policies` | ⚪ 待建立 | - | Policy 治理重構 |

### Infrastructure Domain

| 檔案 | Cluster ID | 狀態 | 最後更新 | 說明 |
|------|------------|------|----------|------|
| _待補充_ | `infra/kubernetes` | ⚪ 待建立 | - | K8s 部署重構 |
| _待補充_ | `infra/monitoring` | ⚪ 待建立 | - | 監控系統重構 |

### Knowledge Domain

| 檔案 | Cluster ID | 狀態 | 最後更新 | 說明 |
|------|------------|------|----------|------|
| _待補充_ | `knowledge/living-kb` | ⚪ 待建立 | - | 活體知識庫重構 |

### Tools Domain

| 檔案 | Cluster ID | 狀態 | 最後更新 | 說明 |
|------|------------|------|----------|------|
| [tools__utility_refactor.md](tools/tools__utility_refactor.md) | `tools/scripts` | 🟡 草稿 | 2025-12-06 | 工具腳本重構 |

---

## 📈 狀態說明

| 狀態 | 圖示 | 說明 |
|------|------|------|
| 完成 | ✅ | 重構計畫完整，已通過審查 |
| 進行中 | 🟢 | 正在執行重構任務 |
| 草稿 | 🟡 | 劇本已建立，但尚未完整 |
| 待建立 | ⚪ | 尚未建立劇本檔案 |
| 已封存 | 🔒 | 已完成並封存，不再更新 |

---

## 🔗 相關資源

- [03_refactor README](README.md) - 重構劇本層說明
- [Templates](templates/) - 劇本模板與規範
- [index.yaml](index.yaml) - 機器可讀索引
- [01_deconstruction/](../01_deconstruction/) - 解構劇本
- [02_integration/](../02_integration/) - 集成劇本
- [PHASE1_COMPLETION_SUMMARY.md](../PHASE1_COMPLETION_SUMMARY.md) - Phase 1 完成總結

---

## 📝 如何更新此索引

### 新增劇本

1. 在對應 domain 子目錄建立劇本檔案
2. 在上方表格新增一行
3. 更新「統計摘要」中的數字
4. 更新 `index.yaml`

### 更新狀態

當劇本狀態變更時：

1. 修改對應行的狀態圖示
2. 更新「最後更新」日期
3. 若狀態為「完成」，更新統計摘要

### 範例

```markdown
| [core__architecture_refactor.md](core/core__architecture_refactor.md) | `core/architecture-stability` | ✅ 完成 | 2026-01-10 | 核心架構穩定性重構 |
```

---

最後更新：2026-01-05
