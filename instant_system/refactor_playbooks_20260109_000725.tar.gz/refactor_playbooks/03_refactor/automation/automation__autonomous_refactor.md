# automation/autonomous 重構劇本（Refactor Playbook）

- Cluster ID：`automation/autonomous`
- 對應目錄：`automation/autonomous/`, `automation/architecture-skeletons/`
- 對應集成劇本：
  - `docs/refactor_playbooks/02_integration/automation__autonomous_integration.md`
- 對應解構劇本：
  - `docs/refactor_playbooks/01_deconstruction/automation__autonomous_deconstruction.md`
- Legacy Assets：
  - _無舊資產需遷移_

---

## 1. Cluster 概覽

### 角色說明

本 cluster 是 **Unmanned Island System 的自主系統框架層**，在系統中扮演以下角色：

- **五骨架自主系統（Five-Skeleton Autonomous System）**的實作
- 提供無人機（Drone）與自駕車（Self-Driving）的控制與整合
- 實作 ROS2 整合與機器人作業系統互動
- 管理感測器融合、路徑規劃、障礙物偵測
- 提供安全監控與緊急接管機制

### 五骨架架構

```text
autonomous/
├─ perception/          # 感知骨架 - 感測器融合、環境感知
├─ planning/            # 規劃骨架 - 路徑規劃、任務規劃
├─ control/             # 控制骨架 - 運動控制、執行器控制
├─ communication/       # 通訊骨架 - 機器間通訊、遠端控制
└─ safety/              # 安全骨架 - 安全監控、緊急停止
```

### 主要語言組成與健康狀態

當前語言分佈：

- **C++** (50%)：ROS2 節點、感測器驅動、即時控制
- **Python** (40%)：高階邏輯、AI 決策、整合層
- **Go** (8%)：API Gateway、遙測收集
- **其他** (2%)：配置檔案、Shell scripts

健康狀態：

- ✅ ROS2 整合穩定
- ✅ C++ 核心控制邏輯效能良好
- ⚠️ Python 與 C++ 介面需標準化
- ⚠️ 缺少完整的模擬測試環境文件

---

## 2. 問題盤點（來源：語言治理 / Hotspot / Semgrep / Flow）

### 語言治理問題彙總

_待補充：從 `governance/language-governance-report.md` 提取 automation/autonomous 相關違規_

預期問題類型：

- Python 型別註解覆蓋率不足
- C++ 程式碼風格不統一
- 跨語言介面文件缺失

### Hotspot 檔案

根據 `apps/web/public/data/hotspot.json` 實際掃描結果：

| 檔案 | Score | 嚴重性 | 問題描述 |
|------|-------|--------|----------|
| `automation/autonomous/flight_controller.lua` | 65 | MEDIUM | Lua 不應用於 autonomous 層，應使用 C++ 或 Python |

**分析**：

1. **`automation/autonomous/flight_controller.lua`** (score: 65, MEDIUM)
   - 問題：Lua in autonomous layer, should use C++ or Python
   - 影響：語言不一致，違反五骨架架構原則
   - 建議：根據功能決定：
     - 即時控制邏輯 → 改寫為 C++
     - 高階協調邏輯 → 改寫為 Python

### Semgrep 安全問題

根據 `governance/semgrep-report.json` 掃描結果：

✅ **目前無 Semgrep 報告的安全問題**

持續關注點（特別針對自主系統）：

- **C++ 記憶體安全**：使用 AddressSanitizer / Valgrind 定期檢測
- **Python 輸入驗證**：所有遠端命令需嚴格驗證
- **通訊安全**：確保所有控制指令使用加密通道（TLS/SSL）
- **緊急停止機制**：定期測試 safety 骨架的可靠性

### Migration Flow 觀察

根據 `apps/web/public/data/migration-flow.json` 分析：

**Outgoing Flows（從 automation/ 流出）**：

1. `automation:lua` → `automation:python` (建議遷移)
   - 行動：將 `flight_controller.lua` 改寫為 Python 或 C++

2. `automation:perl` → `removed` (建議移除)
   - 行動：檢查是否有 Perl 腳本需要清理

**角色定位**：

- automation/autonomous 是語言違規的**來源**之一（有 Lua 違規）
- **相對獨立**：主要與 core/ AI 引擎互動
- **目標狀態**：純 C++ (ROS2/即時) + Python (高階邏輯) + Go (API/遙測)

---

## 3. 語言與結構重構策略

### 語言層級策略

#### 統一主語言

- **C++17/20**：保持為即時控制與 ROS2 節點的主要語言
- **Python 3.10+**：用於高階邏輯、AI 整合、工具腳本
- **Go**：用於 API Gateway 與遙測服務

#### 語言邊界清晰化

```text
C++ 層：
  - ROS2 節點實作
  - 即時感測器處理
  - 低延遲控制迴路

Python 層：
  - 高階決策邏輯
  - AI 模型推理
  - 配置管理與工具

Go 層：
  - HTTP/gRPC API
  - 遙測與日誌收集
  - 監控 Dashboard 後端
```

### 目錄與模組邊界調整

#### 當前結構

```text
automation/autonomous/
├─ architecture-stability/     # ROS2 C++ 實作
├─ api-governance/             # Python API 層
├─ docs-examples/              # 文件與範例
└─ observability-agents/       # Go 觀測代理
```

#### 建議調整

```text
automation/autonomous/
├─ README.md                               # 總覽與架構說明
├─ perception/                             # 感知骨架
│  ├─ ros2_nodes/                          # C++ ROS2 節點
│  ├─ python_integration/                  # Python 包裝層
│  └─ README.md
├─ planning/                               # 規劃骨架
│  ├─ ros2_nodes/
│  ├─ python_integration/
│  └─ README.md
├─ control/                                # 控制骨架
│  ├─ ros2_nodes/
│  ├─ python_integration/
│  └─ README.md
├─ communication/                          # 通訊骨架
│  ├─ ros2_nodes/
│  ├─ api_gateway/                         # Go API Gateway
│  └─ README.md
├─ safety/                                 # 安全骨架
│  ├─ ros2_nodes/
│  ├─ emergency_stop/
│  └─ README.md
├─ observability/                          # 觀測與監控
│  ├─ telemetry_collector/                 # Go 遙測收集
│  ├─ dashboard_backend/                   # Go Dashboard API
│  └─ README.md
├─ simulation/                             # 模擬與測試環境
│  ├─ gazebo_worlds/
│  ├─ test_scenarios/
│  └─ README.md
└─ docs/                                   # 文件與範例
   ├─ architecture.md
   ├─ api_reference.md
   └─ examples/
```

### 與集成方案的對齊

必須符合 `02_integration/automation__autonomous_integration.md` 中定義的：

- ROS2 介面規範（topics, services, actions）
- 與 core/ 的整合點（AI 決策、安全機制）
- 與 automation/intelligent 的協作方式
- API Gateway 的公開介面

---

## 4. 分級重構計畫（P0 / P1 / P2）

### P0（24–48 小時內必須處理）

- 目標：移除語言違規，確保五骨架架構完整性
- 行動項目（檔案層級）：
  - ✅ **行動 1**：評估 `automation/autonomous/flight_controller.lua` (score: 65, MEDIUM)
    - **步驟 1**：分析檔案功能（即時控制 vs 高階邏輯）
    - **步驟 2**：決定目標語言：
      - 如果是即時控制（< 10ms 延遲要求）→ **改寫為 C++**
      - 如果是高階協調邏輯 → **改寫為 Python**
    - **步驟 3**：實作新版本並保持功能等價
    - **步驟 4**：在模擬環境（Gazebo）中驗證
    - **步驟 5**：刪除原始 Lua 檔案
    - **預估時間**：8-16 小時（含模擬測試）
    - **風險評估**：中等（需要充分測試確保飛行安全）
  
  - ✅ **行動 2**：檢查並加固安全機制
    - 驗證所有遠端控制通道使用加密（TLS/SSL）
    - 測試緊急停止機制的反應時間（< 100ms）
    - 確認 safety 骨架的故障切換邏輯
    - **預估時間**：4 小時

- 驗收條件：
  - ✅ automation/autonomous/ 目錄下無 Lua 檔案
  - ✅ Semgrep HIGH severity = 0
  - ✅ 所有遠端控制通道使用加密
  - ✅ 緊急停止機制通過壓力測試（1000 次連續測試無失敗）
  - ✅ 在 Gazebo 模擬環境中通過 10 個標準飛行場景
  - ✅ ROS2 整合測試全部通過

### P1（一週內完成）

- 目標：架構清晰化與五骨架分離
- 行動項目：
  - 重組目錄結構，將分散的模組整合到五骨架框架
    - `architecture-stability/*` → 分配到對應骨架
    - `api-governance/*` → `communication/api_gateway/`
    - `observability-agents/*` → `observability/`
  - 建立各骨架的 README.md 與 API 文件
  - 標準化 Python-C++ 介面（使用 pybind11 或 ROS2 Python bindings）
  - 為 Python 程式碼新增型別註解
- 驗收條件：
  - 目錄結構符合五骨架設計
  - 所有骨架有完整的 README.md
  - Python 型別覆蓋率 > 80%
  - ROS2 介面文件完整

### P2（持續重構）

- 目標：品質提升與開發體驗改善
- 行動項目：
  - 建立完整的模擬測試環境（Gazebo + ROS2）
  - 補充單元測試與整合測試
  - 建立 CI/CD pipeline 用於 ROS2 程式碼
  - 優化感測器融合演算法效能
  - 建立開發者快速上手指南
  - 實作即時監控 Dashboard
- 驗收條件：
  - C++ 測試覆蓋率 > 70%
  - Python 測試覆蓋率 > 80%
  - 所有 ROS2 節點有單元測試
  - 模擬環境可一鍵啟動
  - 文件完整度 > 90%

---

## 5. Auto-Fix Bot 可以處理的項目

### 適合 Auto-Fix 的變更

以下項目可以交給 Auto-Fix Bot：

1. **程式碼格式化**
   - C++：使用 clang-format
   - Python：使用 Black
   - 統一縮排與命名風格

2. **型別註解補強**
   - 為 Python 函式新增型別提示
   - 使用 mypy 驗證型別正確性

3. **簡單重構**
   - 移除未使用的 import
   - 移除 debug print 語句
   - 更新 deprecated API 使用

4. **文件生成**
   - 從 docstring 生成 API 文件
   - 更新 ROS2 介面文件

### 必須人工審查的變更

以下項目必須由人類工程師審查：

1. **即時控制邏輯**
   - 修改 PID 控制參數
   - 變更感測器融合演算法
   - 調整路徑規劃策略

2. **安全機制變更**
   - 修改緊急停止邏輯
   - 變更安全邊界檢查
   - 調整故障偵測與恢復

3. **ROS2 介面變更**
   - 修改 topic/service 定義
   - 變更訊息格式
   - 調整節點間通訊協議

4. **效能關鍵路徑**
   - 優化即時處理迴路
   - 修改記憶體管理策略
   - 調整執行緒同步機制

---

## 6. 驗收條件與成功指標

### 語言治理指標

| 指標 | 當前值 | 目標值 | 驗證方式 |
|------|--------|--------|----------|
| 語言違規數 | **1** (1 MEDIUM: Lua) | **0** | `npm run governance:check` |
| Lua 檔案數 | **1** (`flight_controller.lua`) | **0** | `find automation/ -name "*.lua" \| wc -l` |
| Python 型別覆蓋率 | 待測量 | > 80% | `mypy automation/autonomous/` |
| C++ 靜態分析 | 待執行 | 0 warnings | `clang-tidy automation/autonomous/` |
| Hotspot Score | **Max: 65** (flight_controller.lua) | < 50 | Review hotspot.json |

### 安全指標

| 嚴重性 | 當前數量 | 目標數量 | 驗證方式 |
|--------|----------|----------|----------|
| CRITICAL | **0** ✅ | 0 | Semgrep 掃描 |
| HIGH | **0** ✅ | 0 | Semgrep + 手動代碼審查 |
| MEDIUM | **0** ✅ | <= 2 | Semgrep |
| 記憶體洩漏 | 待檢測 | 0 | Valgrind / AddressSanitizer |
| 緊急停止反應時間 | 待測量 | < 100ms | 壓力測試 |

### 架構指標

- **五骨架完整性**：所有骨架有明確的職責與介面
- **ROS2 介面標準化**：所有節點遵循統一的命名與訊息格式
- **測試覆蓋率**：C++ > 70%, Python > 80%
- **文件完整性**：所有公開介面有文件
- **模擬環境**：可在 Gazebo 中完整測試

---

## 7. 檔案與目錄結構（交付視圖）

### 受影響目錄

- `automation/autonomous/` - 整個自主系統目錄
- `automation/architecture-skeletons/` - 架構骨架（將整合到 autonomous）

### 結構示意（重構後目標）

```text
automation/autonomous/
├─ README.md                                      # 自主系統總覽與五骨架架構說明
├─ perception/                                    # 感知骨架
│  ├─ ros2_nodes/                                 # C++ ROS2 節點
│  │  ├─ sensor_fusion_node/
│  │  ├─ object_detection_node/
│  │  └─ CMakeLists.txt
│  ├─ python_integration/                         # Python 包裝與高階邏輯
│  │  ├─ perception_manager.py
│  │  └─ __init__.py
│  └─ README.md                                   # 感知骨架說明
├─ planning/                                      # 規劃骨架
│  ├─ ros2_nodes/
│  │  ├─ path_planner_node/
│  │  ├─ mission_planner_node/
│  │  └─ CMakeLists.txt
│  ├─ python_integration/
│  │  ├─ planning_manager.py
│  │  └─ __init__.py
│  └─ README.md
├─ control/                                       # 控制骨架
│  ├─ ros2_nodes/
│  │  ├─ motor_controller_node/
│  │  ├─ flight_controller_node/
│  │  └─ CMakeLists.txt
│  ├─ python_integration/
│  │  ├─ control_manager.py
│  │  └─ __init__.py
│  └─ README.md
├─ communication/                                 # 通訊骨架
│  ├─ ros2_nodes/
│  │  ├─ telemetry_node/
│  │  └─ CMakeLists.txt
│  ├─ api_gateway/                                # Go API Gateway
│  │  ├─ main.go
│  │  ├─ handlers/
│  │  └─ README.md
│  └─ README.md
├─ safety/                                        # 安全骨架
│  ├─ ros2_nodes/
│  │  ├─ safety_monitor_node/
│  │  ├─ emergency_stop_node/
│  │  └─ CMakeLists.txt
│  ├─ python_integration/
│  │  ├─ safety_manager.py
│  │  └─ __init__.py
│  └─ README.md
├─ observability/                                 # 觀測與監控
│  ├─ telemetry_collector/                        # Go 遙測收集器
│  │  ├─ main.go
│  │  └─ collectors/
│  ├─ dashboard_backend/                          # Go Dashboard API
│  │  ├─ main.go
│  │  └─ api/
│  └─ README.md
├─ simulation/                                    # 模擬與測試
│  ├─ gazebo_worlds/                              # Gazebo 模擬世界
│  ├─ test_scenarios/                             # 測試場景
│  ├─ launch/                                     # ROS2 launch 檔案
│  └─ README.md
└─ docs/                                          # 文件
   ├─ architecture.md                             # 架構說明
   ├─ api_reference.md                            # API 參考
   ├─ developer_guide.md                          # 開發者指南
   └─ examples/                                   # 範例程式碼
```

### 關鍵檔案說明

- **perception/ros2_nodes/sensor_fusion_node/** - 多感測器融合（LiDAR + Camera + IMU）
- **planning/ros2_nodes/path_planner_node/** - 即時路徑規劃與避障
- **control/ros2_nodes/motor_controller_node/** - 低階馬達控制與 PID 調節
- **communication/api_gateway/** - 遠端控制與遙測的 HTTP/gRPC API
- **safety/ros2_nodes/emergency_stop_node/** - 緊急停止與安全監控

---

## 8. 集成對齊（Integration Alignment）

### 上游依賴

本 cluster 依賴以下服務：

| 服務 | 介面類型 | 用途 |
|------|----------|------|
| `core/ai_engines/decision` | Python Module | AI 決策支援 |
| `core/safety_mechanisms` | Python Module | 安全機制整合 |
| ROS2 Humble | ROS2 | 機器人作業系統 |
| Gazebo | Simulation | 模擬環境 |

### 下游使用者

本 cluster 被以下服務使用：

| 服務 | 介面類型 | 使用方式 |
|------|----------|----------|
| `automation/intelligent` | ROS2 Topics | 高階智能決策 |
| External: Drone Control UI | HTTP API | 遠端控制介面 |
| External: Monitoring | gRPC | 遙測與監控 |

### 集成步驟摘要

重構需按以下順序進行：

1. **Phase 1**：建立新目錄結構（不移動現有程式碼）
   - 建立五骨架目錄與 README
   - 定義各骨架的介面規範
   - 建立模擬測試環境

2. **Phase 2**：漸進式遷移
   - 逐一將現有程式碼移動到對應骨架
   - 更新 CMakeLists.txt 和 package.xml
   - 執行單元測試與整合測試

3. **Phase 3**：驗證與清理
   - 在模擬環境中全面測試
   - 更新所有文件與範例
   - 清理舊目錄

### 回滾策略

若重構失敗：

1. **保留舊結構**：在重構期間，舊目錄結構保持不變
2. **Feature Flag**：使用環境變數控制載入舊/新結構
3. **Symlink 支援**：建立 symlink 保持向後相容
4. **快速切換**：可立即切回舊 ROS2 launch 檔案

### 風險管控

- **硬體測試前先模擬**：所有變更必須先在 Gazebo 中驗證
- **漸進式部署**：先部署非關鍵骨架（如 observability）
- **安全第一**：safety 骨架的變更需要額外審查
- **即時監控**：部署時監控所有感測器與控制指標

---

**狀態**：🟡 草稿（Draft）  
**最後更新**：2025-12-06  
**下一步**：填寫實際的語言治理資料與安全掃描結果，建立模擬測試環境
