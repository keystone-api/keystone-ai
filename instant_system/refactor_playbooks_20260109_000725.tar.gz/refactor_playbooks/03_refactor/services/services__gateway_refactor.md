# services/gateway 重構劇本（Refactor Playbook）

- Cluster ID：`services/gateway`
- 對應目錄：`services/gateway/`, `services/api/`
- 對應集成劇本：
  - `docs/refactor_playbooks/02_integration/services__gateway_integration.md`
- Legacy Assets：
  - `gateway-old-lua-router`

---

## 1. Cluster 概覽

本 cluster 是 **API Gateway 與服務層**，負責：

- API 路由與負載平衡
- 認證與授權整合
- 速率限制與配額管理

### 主要語言與問題

- ⚠️ **Lua** (違規)：舊路由邏輯需移除
- ⚠️ **C++** (層級不當)：不適合服務層
- ✅ TypeScript/Go 是目標語言

---

## 2. 問題盤點

### Hotspot 檔案

| 檔案 | Score | 嚴重性 | 問題 |
|------|-------|--------|------|
| `services/gateway/router.lua` | 88 | HIGH | 禁用語言 + 錯誤層級 |
| `services/api/handler.cpp` | 70 | MEDIUM | C++ 不適合服務層 |

### Migration Flow

- `services:lua` → `removed`
- `services:cpp` → `autonomous:cpp` 或改寫為 TS/Go

---

## 3. P0 行動（24-48小時）

✅ **行動 1**: `services/gateway/router.lua` (score: 88, HIGH)

- **操作**: 改寫為 Go
- **步驟**:
  1. 使用 `gorilla/mux` 或 `chi` 重寫路由
  2. 保持路由規則等價
  3. 新增測試
  4. 灰度發布 (10% → 100%)
- **預估**: 12-16 小時

✅ **行動 2**: 備份至 legacy_scratch

- 更新 `legacy_assets_index.yaml`

### 驗收條件

- ✅ 無 Lua 檔案
- ✅ 功能等價（整合測試通過）
- ✅ 效能無退化 (< 5%)

---

## 4. P1 行動（一週內）

- 評估 `handler.cpp`：改寫為 TS 或 Go
- 重組目錄結構（分離 Go/TS）
- 補充 API 文件 (OpenAPI/gRPC)

---

## 5. 驗收指標

| 指標 | 當前 | 目標 |
|------|------|------|
| 語言違規數 | 2 | 0 |
| Lua 檔案 | 1 | 0 |
| C++ 檔案 | 1 | 0 |
| Hotspot Max | 88 | < 50 |
| 測試覆蓋率 | 待測量 | > 85% |

---

**狀態**: 🟡 實作中  
**最後更新**: 2025-12-06
